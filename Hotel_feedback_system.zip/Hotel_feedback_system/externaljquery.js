$(document).ready(function(){
	$("form[name='myform']").validate({

		rules:{
			cname:
				{
				rangelength: [1,30],
				required:true,
				alphabets:true
				},
			age:
				{
				digits:true,
				required:true,	
				},
			contact:
				{
				digits:true,
				required:true,
				minlength:10,
				maxlength:10
				},
			email:
				{
				rangelength: [1,30],
				required:true,
				email:true
				},
			service:
				{
				required:true,
				},
			food:
				{
				required:true,
				},
			arrangements:
				{
				required:true,
				},
		},
		messages:{
			
			cname:
			{
				rangelength:" !",
				alphabets:" !",
				required:"*",
			},
			age:
				{
				digits:" !",
				required:"*",	
				},
			contact:
			{
				digits:" !",
				required:"*",
				minlength:" !",
				maxlength:" !"
			},
			
			email:
			{
				rangelength:" !",
				required:"*",
				email:" !"
			},
			service:
				{
				required:"*",
				},
			food:
				{
				required:"*",
				},
			arrangements:
				{
				required:"*",
				},
		},
		submitHandler:function(form){
			form.submit();
		}
	});
});
jQuery.validator.addMethod("alphabets",function(value,element){return this.optional(element)||/^[a-zA-Z ]+$/i.test(value);}," !");