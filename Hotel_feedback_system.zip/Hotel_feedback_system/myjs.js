function validateform()
{  
	var letters=/^[A-Za-z]+$/;
	var numletter=/^[0-9A-Za-z]+$/;
	var num=/^[0-9]+$/;
	var phoneno=/^\d{10}$/;
	var nums=/^[0-9/]+$/;
	var emailvalid =/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
	
	var cname=document.myform.cname.value;
	var age=document.myform.age.value;  
	var gender=document.myform.gender.value;
	var contact=document.myform.contact.value;  
	var email=document.myform.email.value;  
	var service=document.myform.service.value;  
	var food=document.myform.food.value;  
	var arrangements=document.myform.arrangements.value;  
	var comments=document.myform.comments.value;  


//Name
	if (cname==null || cname=="")
		{  
		  alert("Name field is compulsory");
		  return false;  
		}
	if (cname.match(letters))
		{
		}
	else
		{
		  alert("Name can contain only alphabets and numbers"); 
		  return false;
		}

//Age
	if (age==null || age=="")
		{  
		  alert("Age field is compulsory");
		  return false;  
		}
	if (age.match(num))
		{
		}
	else
		{
		  alert("Age can contain only numbers"); 
		  return false;
		}

//Contact
	if (contact==null || contact=="")
		{  
		  alert("Contact field is compulsory");
		  return false;  
		}
	if (isNaN(contact))
		{  
		  alert("Contact should be Numeric")  
		  return false;  
		}
	if (contact.match(phoneno))
		{
		}
	else
		{
		  alert("Contact can contain only numbers"); 
		  return false;
		}

//Email
	if(email==null || email=="")
		{  
		  alert("Email field is compulsory");  
		  return false;  
		}

	/*Email Validation*/
	if (email.match(emailvalid))
		{  
		}
	else
		{
	   	  alert("Please enter a valid e-mail address");  
	      	  return false;  
	        }



//Service
	if (service=="notallowed") 
		{
			alert("Service rating is compulsory");
			return false;
        } 

//Food 
    if (food=="notallowed") 
		{
			alert("Food rating is compulsory");
			return false;
        }

//Arrangements  
    if (arrangements=="notallowed") 
		{
			alert("Arrangements rating is compulsory");
			return false;
        } 
	
}

