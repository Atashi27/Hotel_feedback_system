<?php
$cname=$_POST["cname"];
$age=$_POST["age"];
$gender=$_POST["gender"];
$contact=$_POST["contact"];
$email=$_POST["email"];
$service=$_POST["service"];
$food=$_POST["food"];
$arrangements=$_POST["arrangements"];
$comments=$_POST["comments"];
include "connect1.php";
$sql="insert into user_feedback values ('$cname','$age','$gender','$contact','$email','$service','$food','$arrangements','$comments')";
$result=mysqli_query($con,$sql);
?>
<html>
<head lang="en-US">
	<title>Successful feedback</title>
	<meta name="author" content="Atashi">
	<meta name="description" content="Feedback form for Hotel Service">
	<meta name="keyword" content="Hotel,feedback,analysis">
	<link rel="stylesheet" type="text/css" href="style.css"/>
	<link rel="icon" type="image/png" href="logo_hotel.png"/>

</head>
<body>
<div id="a01">
	<table align="center" width="70%" border=0 >
	<tr>
		<th>
		<img src="logo_hotel.png" alt="Logo" height="150" width="150" />
		</th>
		<th>
		<h1>
			<b>Hotel MAHARAJA</b>
			<sub><em>Because food is life</em></sub>
		</h1>
		<h2>
			<b>Feedback Web Portal</b>
		</h2>
		</th>
	</tr>
	</table>
	</div>
	<hr><hr>
	<p><em>~Thankyou for your valuable feedback!!~</em></p>
	<br>
	<p>
	Click <a href="display.php">here</a> for database details
	</p>
</body>
</html>

