<html>
<head lang="en-US">
	<title>Feedback details</title>
	<meta name="author" content="Atashi">
	<meta name="description" content="Feedback form for Hotel Service">
	<meta name="keyword" content="Hotel,feedback,analysis">
	<link rel="stylesheet" type="text/css" href="style.css"/>
	<link rel="icon" type="image/png" href="logo_hotel.png"/>

</head>
<body>
<div id="a01">
	<table align="center" width="70%" border=0 >
	<tr>
		<th>
		<img src="logo_hotel.png" alt="Logo" height="150" width="150" />
		</th>
		<th>
		<h1>
			<b>Hotel MAHARAJA</b>
			<sub><em>Because food is life</em></sub>
		</h1>
		<h2>
			<b>Feedback Web Portal</b>
		</h2>
		</th>
	</tr>
	</table>
	</div>
	<hr><hr>
	<p><em>Database entries are:</em></p>
	</body>
	</html>
<?php
include "connect1.php";
$sql="select * from user_feedback";
$result=$con->query($sql);
if($result->num_rows>0)
{
	echo"<table border=3 align=center><tr><th>Name</th><th>Age</th><th>Gender</th><th>Contact</th><th>Email</th><th>Service rating</th><th>Food ratings</th><th>Arrangement ratings</th><th>Comments</th></tr>";
	while($row=$result->fetch_assoc()){
	echo"<tr><td>".$row["name"]."</td><td>".$row["age"]."</td><td>".$row["gender"]."</td><td>".$row["contact"]."</td><td>".$row["email"]."</td><td>".$row["service"]."</td><td>".$row["food"]."</td><td>".$row["arrangements"]."</td><td>".$row["comments"]."</td></tr>";
	}
	echo"</table>";
}
else
{
	echo"0 results";
}
$con->close();
?>